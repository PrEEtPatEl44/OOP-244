/*/////////////////////////////////////////////////////////////////////////
                          Milestone: 2
Full Name  : Preet Bhagyesh Patel
Student ID#: 132603226
Email      : pbpatel48@myseneca.ca
Date       : 15 November 2023

Authenticity Declaration:
I have done all the coding by myself and only copied the code that my
professor provided to complete my workshops and assignments.
/////////////////////////////////////////////////////////////////////////*/
#define _CRT_SECURE_NO_WARNINGS
#include "AidMan.h"
#include "Utils.h"
#include"Menu.h"
#include"Date.h"
#include "Perishable.h"
#include <iostream>
#include<iomanip>
using namespace std;
#include <cstring>
namespace sdds {
    AidMan::AidMan(const char* filename) : mainMenu("List Items\tAdd Item\tRemove Item\tUpdate Quantity\tSort\tShip Items\tNew/Open Aid Database") {
        ut.alocpy(this->filename, filename);
    }


    AidMan::~AidMan() {
        if (filename)
            deallocate();
            delete[] filename;
            filename = nullptr;
    }


    void AidMan::run() {
        unsigned int userSelection;
        do {
            userSelection = menu();
            if (filename) {
                mainMenu.printSelection(userSelection);
                cin.ignore();
                switch (userSelection) {
                case 1:

                    listItems();
                    break;
                case 2:

                    cout << endl << "****Add Item****" << endl << endl;
                    break;

                case 3:
                    cout << endl << "****Remove Item****" << endl << endl;
                    break;
                case 4:
                    cout << endl << "****Update Quantity****" << endl << endl;
                    break;
                case 5:
                    cout << endl << "****Sort****" << endl << endl;
                    break;
                case 6:
                    cout << endl << "****Ship Items****" << endl << endl;
                    break;
                case 7:
                    cout << endl << "****New/Open Aid Database****" << endl << endl;
                    break;
                case 0:
                    cout << "Exiting Program!" << endl;
                    break;

                }
            }
            else {
                mainMenu.printSelection(7);
                load();
            }

        } while (userSelection != 0);
    }
    void AidMan::listItems() {
        if (list()) {
            cout << "Enter row number to display details or <ENTER> to continue:" << endl << "> ";
            
            if (cin.peek() != '\n') {
                int row = ut.getint();
                m_items[row - 1]->linear(false);
                m_items[row - 1]->display(cout) << endl;
            }
            else {
                cout << endl;
                cin.ignore();
            }
        }
    }

    unsigned int AidMan::menu()const {
        cout <<"Aid Management System" << endl;
        cout << "Date: " << Date() << endl;
        if (filename)
        {
            cout << "Data file: " << filename << endl ;
        }
        else
        {
            cout << "Data file: No file" << endl ;
        }
        cout << "---------------------------------" << endl;


        unsigned int val = this->mainMenu.run();
        return val;
    }
    void AidMan::save() {
        if (filename) { //Checking if theres is a filename
            ofstream file(filename); //Opening file
            for (int i = 0; i < m_noItems; i++) {
                m_items[i]->save(file) << endl; //Calling the save function of each item
            }
            file.close(); //Closing the file
        }

    }
    void AidMan::deallocate() {
        if (m_items != nullptr) {
            for (int i = 0; i < m_noItems; i++) {
                delete m_items[i]; //Cleaning the classes
                m_items[i] = nullptr;
            }
            m_noItems = 0; //Reseting the number of items
        }
    }
    bool AidMan::load() {
        save(); //Saving old Records
        deallocate(); //Deletin all records
        cin.ignore(); //Remove Garbage from the buffer

        //Check for file existence and create if necessary

        if (filename) { //Checking if the file exists
            ifstream file(filename); //Opening check for existence
            if (file.is_open()) { //Check if the file was openned correctly
                cout << "Failed to open " << filename << " for reading!" << endl;
                cout << "Would you like to create a new data file?" << endl;
                Menu menu("1- Yes!");
                if (menu.run()) { //Getting User menu input
                    char temp[1000]{ '\0' };
                    cin.getline(temp, 1000, '\n'); //Getting file in temporary var
                    delete[] filename;
                    filename = nullptr;
                    ut.alocpy(filename, temp); //Dynamically allocating the file name
                    ofstream outputFile(filename); //Creating the new file
                    outputFile << "";
                    outputFile.close();
                }
                else cout << "Exiting Program!" << endl;
            }
            file.close(); //Securely closing the checking file
        }
        else { //If file name is not declared
            cout << "Enter file name: ";
            char temp[1000]{ '\0' };
            cin.getline(temp, 1000, '\n'); //Get file name is temporary var
            ut.alocpy(filename, temp); //Dinamically allocating the file name
        }

        //Readinf from the verified file 

        ifstream file(filename); //Opening the reading file
        int i;
        for (i = 0; i < sdds_max_num_items; i++) {
            int peek = file.peek(); //Looking in ASCII the next char

            if (peek >= 49 && peek <= 51) { //If its between 1 and 3 inclusively
                m_items[i] = new Perishable;
                if (m_items[i]->load(file)) { m_noItems++; } //If loaded correctly increment the number of items
                else {	
                    if (m_items[i] != nullptr) {//If not delete the created Perishable
                        delete m_items[i];
                        m_items[i] = nullptr;
                    }
                }
            }
            else if (peek >= 52 && peek <= 57) { //If its between 4 and 9 inclusively
                m_items[i] = new Item;
                if (m_items[i]->load(file)) m_noItems++; //If loaded correctly increment the number of items
                else { 									 //If not delete the created Item
                    delete m_items[i];
                    m_items[i] = nullptr;
                }
            }
            else file.setstate(std::ios::failbit);	//If its different set the state of the file to fail
        }
        cout << m_noItems << " records loaded!" << endl<<endl; //Report the loaded records
        file.close(); //Safely close 
        return m_noItems;
    }
    int AidMan::list(const char* sub_desc) {
        int counter{ 0 };
        cout << " ROW |  SKU  | Description                         | Have | Need |  Price  | Expiry" << endl;
        cout << "-----+-------+-------------------------------------+------+------+---------+-----------" << endl;
        for (int i = 0; i < m_noItems; i++)
        {
            if (!sub_desc) { //Check if the substring is given
                m_items[i]->linear(true); //Changes the format of the product
                cout << std::setw(4) << std::setfill(' ') << std::right << (i + 1) << " | "; //Prints row number
                m_items[i]->display(cout) << endl; //Prints Product
                counter++;
            }
            else {
                if (m_items[i]->subString(sub_desc)) { //Check if the substring is present
                    m_items[i]->linear(true);
                    cout << std::setw(4) << std::setfill(' ') << std::right << (i + 1) << " | ";
                    m_items[i]->display(cout) << endl;
                    counter++;
                }
            }
        }
        cout << "-----+-------+-------------------------------------+------+------+---------+-----------" << endl;
        return counter;
    }
}
